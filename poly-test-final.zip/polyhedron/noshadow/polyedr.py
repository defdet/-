from math import pi, fabs, sqrt
from common.r3 import R3
from common.tk_drawer import TkDrawer


class Edge:
    """ Ребро полиэдра """
    # Параметры конструктора: начало и конец ребра (точки в R3)

    def __init__(self, beg, fin):
        self.beg, self.fin = beg, fin


class Facet:
    """ Грань полиэдра """
    # Параметры конструктора: список вершин

    def __init__(self, vertexes):
        self.vertexes = vertexes


class Polyedr:
    """ Полиэдр """
    # Параметры конструктора: файл, задающий полиэдр

    def __init__(self, file):

        # списки вершин, рёбер и граней полиэдра
        self.vertexes, self.edges, self.facets = [], [], []

        # список строк файла
        with open(file) as f:
            for i, line in enumerate(f):
                if i == 0:
                    # обрабатываем первую строку; buf - вспомогательный массив
                    buf = line.split()
                    # коэффициент гомотетии
                    c = float(buf.pop(0))
                    # углы Эйлера, определяющие вращение
                    alpha, beta, gamma = (float(x) * pi / 180.0 for x in buf)
                elif i == 1:
                    # во второй строке число вершин, граней и рёбер полиэдра
                    nv, nf, ne = (int(x) for x in line.split())
                elif i < nv + 2:
                    # задание всех вершин полиэдра
                    x, y, z = (float(x) for x in line.split())
                    self.vertexes.append(R3(x, y, z).rz(
                        alpha).ry(beta).rz(gamma) * c)
                else:
                    # вспомогательный массив
                    buf = line.split()
                    # количество вершин очередной грани
                    size = int(buf.pop(0))
                    # массив вершин этой грани
                    vertexes = [self.vertexes[int(n) - 1] for n in buf]
                    # задание рёбер грани
                    for n in range(size):
                        self.edges.append(Edge(vertexes[n - 1], vertexes[n]))
                    # задание самой грани
                    self.facets.append(Facet(vertexes))

    # Метод, определяющий, является ли точка "хорошей"
    @staticmethod
    def is_good_point(point, threshold=1):
        return fabs(point.x) < threshold and fabs(point.y) < threshold

    # Метод для подсчета суммы длин проекций рёбер, оба из концов которых — "хорошие" точки
    def calculate_good_edge_lengths(self):
        good_edge_lengths = 0.0
        good_edge_xy = 0.0
        for e in self.edges:
            if self.is_good_point(e.beg) and self.is_good_point(e.fin): # Оба конца являются "хорошими"
                edge = (e.fin - e.beg) # "Вектор ребра"
                good_edge_lengths += sqrt(edge.dot(edge)) # Скалярное произведение вектора самого на себя дает длину вектора в квадрате
                good_edge_xy += sqrt(edge.x ** 2 + edge.y ** 2) # Теорема Пифагора
        return good_edge_lengths, good_edge_xy

    # Метод изображения полиэдра
    def draw(self, tk):
        tk.clean()
        for e in self.edges:
            tk.draw_line(e.beg, e.fin)
        lengts_sum, xy_sum = self.calculate_good_edge_lengths()
        print(f"Сумма длин 'хороших' ребер равна {lengts_sum}. Сумма длин проекций ребер равна {xy_sum}")

